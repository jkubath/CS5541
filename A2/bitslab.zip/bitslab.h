
int bitAnd(int x, int y);
int getByte(int x, int n);
int logicalShift(int x, int n);
int bitCount(int x);
int bang(int x);
int tmin(void);
int fitsBits(int x, int n);
int divpwr2(int x, int n);
int negate(int x);
int isPositive(int x);
int isLessOrEqual(int x, int y);
unsigned float_neg(unsigned uf);
unsigned float_i2f(int x);
unsigned float_twice(unsigned uf);
