package scheduling_JonahKubath;

import java.util.Scanner;

public class Scan {
	static Scanner scan = new Scanner(System.in);
	
	public static void close() {
		scan.close();
	}

}
