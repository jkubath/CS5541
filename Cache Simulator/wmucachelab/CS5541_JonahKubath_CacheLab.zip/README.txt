Date: 02/22/2018
Class: CS5541
Assignment: A3 Memory Cache
Author(s): Jonah Kubath


make
make use

Warnings: None.

References:
  -g is used in compilation to add debugging symbols
    https://www.cprogramming.com/debugging/valgrind.html
