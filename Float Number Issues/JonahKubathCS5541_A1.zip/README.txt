Date: 01/22/2018
Class: CS5541
Assignment: A1 Number Demonstrations
Author(s): Jonah Kubath


gcc -std=c99 -Wall -o JonahKubathA1 JonahKubathA1.c

make all
make use

Warnings: I had a couple of warnings but I was supposed to!
  Number overflows are purposely there.

References: I did this on my own with no research


Results:

make use
./JonahKubathA1
Problem 1:
Expected - 3.6000000000
3.5999999046

Problem 2:
Expected - 0.1
0.1000000015

Problem 3:
Expected - 0.5
0.000000e+00
Expected - 0.5
5.000000e-01

Problem 4:
Expected - 9999999.4499999999
Double - 9.999999e+06
Float - 9999999.000000

Problem 5:
Expected - 900,000,000
900000000
Expected - 1,600,000,000
1600000000
Expected - 2,500,000,000
-1794967296
Expected - 3,600,000,000
-694967296

Problem 6:
Expected - 100,000,000,000,000,000,000
100000002004087734272.000000
Expected - 100,000,000,003,500,000,000
100000002004087734272.000000
Expected - 103,500,000,000,000,000,000
103500002601996386304.000000
100000002004087734272.000000