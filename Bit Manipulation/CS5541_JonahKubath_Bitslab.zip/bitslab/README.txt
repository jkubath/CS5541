Date: 02/5/2018
Class: CS5541
Assignment: A2 Bits Lab
Author(s): Jonah Kubath


gcc -std=c99 -Wall -o JonahKubathA2 test.c bitslab.c

make all
make use

Warnings: None.

References:
  The bang function was taken from an in class work sheet
  The bit count was taken from https://stackoverflow.com/questions/3815165/how-to-implement-bitcount-using-only-bitwise-operators
